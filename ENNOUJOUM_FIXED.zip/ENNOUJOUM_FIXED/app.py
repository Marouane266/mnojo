"""ENNOUJOUM - Application Flask principale.

Tout est modularisé via des blueprints dans des fichiers séparés
(chaque fichier ≤ 100 lignes).
"""
from flask import Flask, render_template, redirect, url_for, session, flash

from config import SECRET_KEY
from database import init_db
import routes_employee, routes_client, routes_manager, routes_manager_actions

app = Flask(__name__)
app.secret_key = SECRET_KEY

# Blueprints
app.register_blueprint(routes_employee.bp)
app.register_blueprint(routes_client.bp)
app.register_blueprint(routes_manager.bp)
app.register_blueprint(routes_manager_actions.bp)
routes_client.register_api(app)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Vous êtes déconnecté.", "success")
    return redirect(url_for("home"))


# Compat avec anciens liens éventuels
@app.route("/admin/login")
def _admin_login_compat():
    return redirect(url_for("manager.login"))


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
