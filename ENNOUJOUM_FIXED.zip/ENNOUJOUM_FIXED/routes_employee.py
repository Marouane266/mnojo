"""Routes Employé — ENNOUJOUM."""
from flask import (Blueprint, render_template, request, redirect, url_for,
                   session, flash, get_flashed_messages)
from database import get_db_connection
from helpers import (login_required, generate_unique_code, send_whatsapp,
                     build_whatsapp_link, now_str)
from config import PRICES

bp = Blueprint("employee", __name__, url_prefix="/employee")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "").strip()
        conn = get_db_connection()
        emp = conn.execute(
            "SELECT * FROM employees WHERE username=? AND password=?", (u, p)
        ).fetchone()
        conn.close()
        if emp:
            session["role"] = "employee"
            session["user_id"] = emp["id"]
            session["username"] = emp["username"]
            return redirect(url_for("employee.dashboard"))
        flash("Identifiants invalides.", "error")
    return render_template("employee_login.html")


@bp.route("/dashboard")
@login_required("employee")
def dashboard():
    conn = get_db_connection()
    cars = conn.execute("SELECT * FROM cars ORDER BY id DESC").fetchall()
    conn.close()
    wa = get_flashed_messages(category_filter=["whatsapp"])
    return render_template("employee_dashboard.html",
                           cars=cars, prices=PRICES,
                           username=session.get("username"),
                           pending_whatsapp=wa[-1] if wa else None,
                           build_whatsapp_link=build_whatsapp_link)


@bp.route("/register_car", methods=["POST"])
@login_required("employee")
def register_car():
    car_type = request.form.get("car_type")
    phone = request.form.get("phone", "").strip()
    wash = request.form.get("wash_type")
    if not car_type or not phone or wash not in PRICES:
        flash("Champs invalides.", "error")
        return redirect(url_for("employee.dashboard"))
    if not phone.replace("+", "").replace(" ", "").isdigit():
        flash("Le téléphone doit contenir uniquement des chiffres.", "error")
        return redirect(url_for("employee.dashboard"))

    code = generate_unique_code()
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO cars (code,car_type,phone,wash_type,price,status,date)"
        " VALUES (?,?,?,?,?,?,?)",
        (code, car_type, phone, wash, PRICES[wash], "Started", now_str()))
    conn.commit()
    conn.close()
    wa = send_whatsapp(phone,
                       "سيصلك رمز التتبع الخاص بك: " + code, code=code)
    flash(wa["link"], "whatsapp")
    flash("Voiture enregistrée. Code : " + code, "success")
    return redirect(url_for("employee.dashboard"))


@bp.route("/update_status/<int:car_id>", methods=["POST"])
@login_required("employee")
def update_status(car_id):
    new = request.form.get("status")
    if new not in ("Started", "In Progress", "Finished"):
        return redirect(url_for("employee.dashboard"))
    conn = get_db_connection()
    car = conn.execute("SELECT * FROM cars WHERE id=?", (car_id,)).fetchone()
    if car:
        conn.execute("UPDATE cars SET status=? WHERE id=?", (new, car_id))
        conn.commit()
    conn.close()
    if car and new == "Finished":
        wa = send_whatsapp(car["phone"],
                           "سيارتك جاهزة. يرجى القدوم لاستلامها.",
                           code=car["code"])
        flash(wa["link"], "whatsapp")
    flash("Statut mis à jour : " + new, "success")
    return redirect(url_for("employee.dashboard"))


@bp.route("/send_reminder/<int:car_id>", methods=["POST"])
@login_required("employee")
def send_reminder(car_id):
    conn = get_db_connection()
    car = conn.execute("SELECT * FROM cars WHERE id=?", (car_id,)).fetchone()
    conn.close()
    if car:
        wa = send_whatsapp(car["phone"],
                           "تذكير : سيارتك (الرمز " + car["code"] + ") لا تزال في انتظار الاستلام.",
                           code=car["code"])
        flash(wa["link"], "whatsapp")
        flash("Rappel envoyé.", "success")
    return redirect(url_for("employee.dashboard"))
