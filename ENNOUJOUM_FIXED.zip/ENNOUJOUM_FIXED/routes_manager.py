"""Routes Manager — inscription, connexion, validation, dashboard."""
from datetime import timedelta
from flask import (Blueprint, render_template, request, redirect, url_for,
                   session, flash)
from database import get_db_connection
from helpers import login_required, WHATSAPP_LOG, now_local

bp = Blueprint("manager", __name__, url_prefix="/manager")


@bp.route("/register", methods=["GET", "POST"])
def register():
    """Inscription. Le 1er manager est auto-approuvé.
    Les suivants restent en attente d'approbation."""
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "").strip()
        if not u or not p:
            flash("Tous les champs sont requis.", "error")
            return redirect(url_for("manager.register"))
        conn = get_db_connection()
        if conn.execute("SELECT id FROM managers WHERE username=?", (u,)).fetchone():
            conn.close()
            flash("Ce nom d'utilisateur existe déjà.", "error")
            return redirect(url_for("manager.register"))
        count = conn.execute("SELECT COUNT(*) c FROM managers").fetchone()["c"]
        approved = 1 if count == 0 else 0
        conn.execute("INSERT INTO managers (username,password,approved) VALUES (?,?,?)",
                     (u, p, approved))
        conn.commit()
        conn.close()
        if approved:
            flash("Compte créé. Vous pouvez vous connecter.", "success")
        else:
            flash("Demande envoyée. En attente d'approbation par un manager existant.", "info")
        return redirect(url_for("manager.login"))
    return render_template("manager_register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "").strip()
        conn = get_db_connection()
        m = conn.execute("SELECT * FROM managers WHERE username=? AND password=?",
                         (u, p)).fetchone()
        conn.close()
        if not m:
            flash("Identifiants invalides.", "error")
        elif not m["approved"]:
            flash("Compte en attente d'approbation.", "error")
        else:
            session["role"] = "admin"
            session["username"] = m["username"]
            session["user_id"] = m["id"]
            return redirect(url_for("manager.dashboard"))
    return render_template("manager_login.html")


@bp.route("/dashboard")
@login_required("admin")
def dashboard():
    conn = get_db_connection()
    cars = conn.execute("SELECT * FROM cars ORDER BY id DESC").fetchall()
    employees = conn.execute("SELECT * FROM employees ORDER BY id").fetchall()
    pending = conn.execute(
        "SELECT id,username,created_at FROM managers WHERE approved=0").fetchall()
    conn.close()
    today = now_local().date()
    week = today - timedelta(days=7)
    month = today - timedelta(days=30)
    d = w = mo = 0
    for c in cars:
        try:
            cd = c["date"][:10]
            from datetime import datetime as dt
            cdate = dt.strptime(cd, "%Y-%m-%d").date()
        except Exception:
            continue
        if cdate == today: d += c["price"]
        if cdate >= week: w += c["price"]
        if cdate >= month: mo += c["price"]
    stats = {
        "total_cars": len(cars), "daily_revenue": d,
        "weekly_revenue": w, "monthly_revenue": mo,
        "finished": sum(1 for c in cars if c["status"] == "Finished"),
        "in_progress": sum(1 for c in cars if c["status"] == "In Progress"),
        "started": sum(1 for c in cars if c["status"] == "Started"),
    }
    return render_template("admin_dashboard.html",
                           cars=cars, employees=employees, stats=stats,
                           pending_managers=pending,
                           whatsapp_log=list(reversed(WHATSAPP_LOG[-15:])))
