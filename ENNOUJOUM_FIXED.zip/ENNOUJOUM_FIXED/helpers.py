"""Fonctions utilitaires partagées — ENNOUJOUM."""
import random
import urllib.parse
from datetime import datetime
from functools import wraps
from flask import session, flash, redirect, url_for

from database import get_db_connection
from config import TIMEZONE

try:
    from zoneinfo import ZoneInfo
    _TZ = ZoneInfo(TIMEZONE)
except Exception:
    _TZ = None

# Journal en mémoire des messages WhatsApp
WHATSAPP_LOG = []


def now_local():
    """Heure locale (corrige les décalages UTC sur les serveurs cloud)."""
    if _TZ is not None:
        return datetime.now(_TZ)
    return datetime.now()


def now_str():
    return now_local().strftime("%Y-%m-%d %H:%M:%S")


def generate_unique_code():
    conn = get_db_connection()
    while True:
        code = str(random.randint(100, 999))
        if not conn.execute("SELECT id FROM cars WHERE code=?", (code,)).fetchone():
            conn.close()
            return code


def build_whatsapp_link(phone, message):
    clean = "".join(c for c in str(phone) if c.isdigit())
    if clean.startswith("0"):
        clean = "212" + clean[1:]
    return "https://wa.me/" + clean + "?text=" + urllib.parse.quote(message)


def send_whatsapp(phone, message, code=None):
    entry = {
        "phone": phone, "message": message,
        "time": now_str(), "code": code,
        "link": build_whatsapp_link(phone, message),
    }
    WHATSAPP_LOG.append(entry)
    return entry


def login_required(role):
    def deco(f):
        @wraps(f)
        def wrap(*a, **kw):
            if session.get("role") != role:
                flash("Veuillez vous connecter.", "error")
                return redirect(url_for("home"))
            return f(*a, **kw)
        return wrap
    return deco
