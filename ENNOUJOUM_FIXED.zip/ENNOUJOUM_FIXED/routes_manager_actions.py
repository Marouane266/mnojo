"""Actions Manager : gérer employés et valider managers."""
from flask import Blueprint, request, redirect, url_for, flash, session
from database import get_db_connection
from helpers import login_required

bp = Blueprint("manager_actions", __name__, url_prefix="/manager")


@bp.route("/create_employee", methods=["POST"])
@login_required("admin")
def create_employee():
    u = request.form.get("username", "").strip()
    p = request.form.get("password", "").strip()
    if not u or not p:
        flash("Nom d'utilisateur et mot de passe requis.", "error")
        return redirect(url_for("manager.dashboard"))
    conn = get_db_connection()
    if conn.execute("SELECT id FROM employees WHERE username=?", (u,)).fetchone():
        conn.close()
        flash("Cet utilisateur existe déjà.", "error")
        return redirect(url_for("manager.dashboard"))
    conn.execute("INSERT INTO employees (username,password) VALUES (?,?)", (u, p))
    conn.commit()
    conn.close()
    flash("Employé '" + u + "' créé.", "success")
    return redirect(url_for("manager.dashboard"))


@bp.route("/delete_employee/<int:emp_id>", methods=["POST"])
@login_required("admin")
def delete_employee(emp_id):
    conn = get_db_connection()
    e = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if e:
        conn.execute("DELETE FROM employees WHERE id=?", (emp_id,))
        conn.commit()
        flash("Employé '" + e["username"] + "' supprimé.", "success")
    conn.close()
    return redirect(url_for("manager.dashboard"))


@bp.route("/approve_manager/<int:mid>", methods=["POST"])
@login_required("admin")
def approve_manager(mid):
    conn = get_db_connection()
    conn.execute("UPDATE managers SET approved=1 WHERE id=?", (mid,))
    conn.commit()
    conn.close()
    flash("Manager approuvé.", "success")
    return redirect(url_for("manager.dashboard"))


@bp.route("/reject_manager/<int:mid>", methods=["POST"])
@login_required("admin")
def reject_manager(mid):
    conn = get_db_connection()
    # on ne peut pas se supprimer soi-même
    if session.get("user_id") == mid:
        flash("Action impossible.", "error")
    else:
        conn.execute("DELETE FROM managers WHERE id=? AND approved=0", (mid,))
        conn.commit()
        flash("Demande rejetée.", "success")
    conn.close()
    return redirect(url_for("manager.dashboard"))
