"""Routes Client — ENNOUJOUM."""
from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, jsonify)
from database import get_db_connection

bp = Blueprint("client", __name__, url_prefix="/client")


@bp.route("", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        code = request.form.get("code", "").strip()
        if not code:
            flash("Veuillez saisir votre code.", "error")
            return redirect(url_for("client.login"))
        return redirect(url_for("client.track", code=code))
    return render_template("client_login.html")


@bp.route("/track/<code>")
def track(code):
    conn = get_db_connection()
    car = conn.execute("SELECT * FROM cars WHERE code=?", (code,)).fetchone()
    conn.close()
    if not car:
        flash("Aucune voiture trouvée pour le code " + code + ".", "error")
        return redirect(url_for("client.login"))
    return render_template("client_track.html", car=car)


def register_api(app):
    """Endpoint JSON utilisé par le rafraichissement auto."""
    @app.route("/api/status/<code>")
    def api_status(code):
        conn = get_db_connection()
        car = conn.execute("SELECT * FROM cars WHERE code=?", (code,)).fetchone()
        conn.close()
        if not car:
            return jsonify({"found": False}), 404
        return jsonify({
            "found": True, "code": car["code"], "status": car["status"],
            "wash": car["wash_type"], "price": car["price"]
        })
