"""Configuration centralisée pour ENNOUJOUM."""
import os

SECRET_KEY = os.environ.get("ENNOUJOUM_SECRET", "ennoujoum_super_secret_key_2026")

# Fuseau horaire local (Maroc) — corrige le décalage d'1h sur les serveurs UTC
TIMEZONE = "Africa/Casablanca"

# Tarifs en MAD (Dirham marocain)
PRICES = {
    "Normal":  40,
    "Pro":     70,
    "Pro Max": 300,
}

DB_NAME = os.environ.get("ENNOUJOUM_DB", "ennoujoum.db")
