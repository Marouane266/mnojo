"""Initialisation SQLite — ENNOUJOUM.

Tables :
  - cars       : voitures enregistrées
  - employees  : comptes employés (créés par le manager — AUCUN par défaut)
  - managers   : comptes managers (1er auto-approuvé, suivants à valider)

Aucun identifiant par défaut n'est inséré.
"""
import sqlite3
import os
from config import DB_NAME


def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    first_time = not os.path.exists(DB_NAME)
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS cars (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            code      TEXT    UNIQUE NOT NULL,
            car_type  TEXT    NOT NULL,
            phone     TEXT    NOT NULL,
            wash_type TEXT    NOT NULL,
            price     INTEGER NOT NULL,
            status    TEXT    NOT NULL DEFAULT 'Started',
            date      TEXT    NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT    UNIQUE NOT NULL,
            password TEXT    NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS managers (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            username  TEXT    UNIQUE NOT NULL,
            password  TEXT    NOT NULL,
            approved  INTEGER NOT NULL DEFAULT 0,
            created_at TEXT   NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
    print("[DB] " + ("created" if first_time else "ready") + " : " + DB_NAME)


if __name__ == "__main__":
    init_db()
