/* i18n.js — application des traductions */
(function () {
  const DICTS = { fr: window.I18N_FR, ar: window.I18N_AR };
  const KEY = 'ennoujoum_lang';

  function getLang() { return localStorage.getItem(KEY) || 'fr'; }
  function setLang(l) {
    if (l !== 'fr' && l !== 'ar') l = 'fr';
    localStorage.setItem(KEY, l);
    apply(l);
  }
  function apply(lang) {
    const dict = DICTS[lang] || DICTS.fr;
    const html = document.documentElement;
    html.setAttribute('lang', lang);
    html.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      if (dict[k]) el.textContent = dict[k];
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const k = el.getAttribute('data-i18n-placeholder');
      if (dict[k]) el.setAttribute('placeholder', dict[k]);
    });
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
      const k = el.getAttribute('data-i18n-title');
      if (dict[k]) el.setAttribute('title', dict[k]);
    });
    const sm = {
      "Started": dict["status.started"],
      "In Progress": dict["status.in_progress"],
      "Finished": dict["status.finished"]
    };
    document.querySelectorAll('[data-status-text]').forEach(el => {
      const o = el.getAttribute('data-status-text');
      if (sm[o]) el.textContent = sm[o];
    });
    document.querySelectorAll('option[data-i18n-status]').forEach(o => {
      const v = o.getAttribute('data-i18n-status');
      if (sm[v]) o.textContent = sm[v];
    });
    const btn = document.getElementById('lang-toggle');
    if (btn) btn.textContent = dict["common.lang.toggle"];
  }
  window.ENNJ_I18N = { getLang, setLang, apply };
})();
