/* theme.js — thème clair/sombre */
(function () {
  const KEY = 'ennoujoum_theme';
  function get() { return localStorage.getItem(KEY) || 'light'; }
  function set(t) {
    if (t !== 'light' && t !== 'dark') t = 'light';
    localStorage.setItem(KEY, t);
    document.documentElement.setAttribute('data-theme', t);
  }
  function toggle() { set(get() === 'dark' ? 'light' : 'dark'); }
  document.documentElement.setAttribute('data-theme', get());
  window.ENNJ_THEME = { get, set, toggle };
})();
