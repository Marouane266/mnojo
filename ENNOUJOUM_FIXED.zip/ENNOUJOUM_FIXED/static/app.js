/* app.js — orchestration UI + horloge locale */
document.addEventListener('DOMContentLoaded', () => {
  const I = window.ENNJ_I18N, T = window.ENNJ_THEME;
  I.apply(I.getLang());

  const tBtn = document.getElementById('theme-toggle');
  if (tBtn) tBtn.addEventListener('click', T.toggle);

  const lBtn = document.getElementById('lang-toggle');
  if (lBtn) lBtn.addEventListener('click',
    () => I.setLang(I.getLang() === 'fr' ? 'ar' : 'fr'));

  // Auto-dismiss flash messages (sauf whatsapp)
  document.querySelectorAll('.flash').forEach(f => {
    setTimeout(() => {
      f.style.transition = 'opacity .4s, transform .4s';
      f.style.opacity = '0';
      f.style.transform = 'translateX(40px)';
      setTimeout(() => f.remove(), 400);
    }, 4500);
  });

  // Confirm logout
  document.querySelectorAll('.btn-logout').forEach(b => {
    b.addEventListener('click', e => {
      const d = (I.getLang() === 'ar' ? window.I18N_AR : window.I18N_FR);
      if (!confirm(d["common.confirm.logout"])) e.preventDefault();
    });
  });

  // Filter tracking-code input
  const ci = document.getElementById('code');
  if (ci) ci.addEventListener('input', e => {
    e.target.value = e.target.value.replace(/[^0-9]/g, '').slice(0, 3);
  });

  // Horloge locale (heure du navigateur — corrige le décalage UTC)
  const clock = document.getElementById('local-clock');
  if (clock) {
    const tick = () => {
      const n = new Date();
      const pad = x => String(x).padStart(2, '0');
      clock.textContent =
        pad(n.getHours()) + ':' + pad(n.getMinutes()) + ':' + pad(n.getSeconds());
    };
    tick();
    setInterval(tick, 1000);
  }
});
